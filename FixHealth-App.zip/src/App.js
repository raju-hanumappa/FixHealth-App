import './App.css';
import ConsultForm from './Components'

function App() {
  return (
    <div>
      <ConsultForm/>
    </div>
  );
}

export default App;
